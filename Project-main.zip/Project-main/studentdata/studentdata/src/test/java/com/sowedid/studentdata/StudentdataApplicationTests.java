package com.sowedid.studentdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentdataApplicationTests {

	@Test
	void contextLoads() {
	}

}
