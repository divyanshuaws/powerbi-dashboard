package com.sowedid.responsedto;

public class StudentResponseDTO {
	 private long id;
	    private String name;
	    private long rollno;
	    private String course;
	    private int age;
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public long getRollno() {
			return rollno;
		}
		public void setRollno(long rollno) {
			this.rollno = rollno;
		}
		public String getCourse() {
			return course;
		}
		public void setCourse(String course) {
			this.course = course;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
	    

}
