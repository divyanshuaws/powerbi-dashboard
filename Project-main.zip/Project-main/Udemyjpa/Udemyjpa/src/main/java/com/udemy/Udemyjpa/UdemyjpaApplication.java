package com.udemy.Udemyjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdemyjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(UdemyjpaApplication.class, args);
	}

}
