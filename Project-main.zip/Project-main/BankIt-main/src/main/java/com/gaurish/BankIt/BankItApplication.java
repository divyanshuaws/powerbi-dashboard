package com.gaurish.BankIt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankItApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankItApplication.class, args);
	}

}
