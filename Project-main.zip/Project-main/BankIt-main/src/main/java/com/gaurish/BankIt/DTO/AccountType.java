package com.gaurish.BankIt.DTO;

public enum AccountType {
    SAVING,
    SALARY,
    CURRENT;
}
