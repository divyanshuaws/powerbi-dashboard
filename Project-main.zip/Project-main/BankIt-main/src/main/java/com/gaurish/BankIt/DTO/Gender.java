package com.gaurish.BankIt.DTO;

public enum Gender {
    MALE,FEMALE, OTHER;
}
