package com.example.vikas.springcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarvelSuperheroesSpringBootCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
