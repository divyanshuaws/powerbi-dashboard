//package com.bitsnbytes.productlist.security;

//public class Secu {

    //    @Bean
//    public UserDetailsService userDetailsService(){
//        UserDetails admin= User.builder()
//                .username("admin")
//                .password(passwordEncoder().encode("admin"))
//                .roles("ADMIN")
//                .build();
//
//
//
//            UserDetails seller= User.builder()
//                    .username("seller")
//                    .password(passwordEncoder().encode("seller"))
//                    .roles("SELLER")
//                    .build();
//
//
//            return new InMemoryUserDetailsManager(admin,seller);
//}
