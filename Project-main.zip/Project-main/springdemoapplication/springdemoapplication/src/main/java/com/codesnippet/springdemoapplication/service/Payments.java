package com.codesnippet.springdemoapplication.service;

public interface Payments {
    void processPayment(double amount);


}
