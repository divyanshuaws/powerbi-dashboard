//package com.codesnippet.springdemoapplication.entity;
//
//import jakarta.annotation.PostConstruct;
//import jakarta.persistence.Entity;
//import org.springframework.context.annotation.Scope;
//import org.springframework.stereotype.Component;
//
////@Entity
//@Component
//@Scope("singleton")
//public class User {
//
//    public User() {
//        System.out.println("constructor inalize");
//    }
//    @PostConstruct
//    public void init(){
//        System.out.println("user object hashcode"+this.hashCode());
//
//    }
//}
