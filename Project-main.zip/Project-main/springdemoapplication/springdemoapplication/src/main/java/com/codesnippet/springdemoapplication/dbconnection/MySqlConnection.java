package com.codesnippet.springdemoapplication.dbconnection;

import org.springframework.stereotype.Component;

@Component
public class MySqlConnection {

    public MySqlConnection() {
        System.out.println("Mysqlconnection");
    }
}
