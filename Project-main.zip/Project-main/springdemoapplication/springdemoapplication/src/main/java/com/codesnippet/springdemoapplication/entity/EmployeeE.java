package com.codesnippet.springdemoapplication.entity;


public class EmployeeE {

    String name;
    Integer empid;
    String department;
}
