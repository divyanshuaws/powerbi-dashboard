package com.codesnippet.springdemoapplication.service;

import org.junit.jupiter.api.Test;

public class ProductServiceTest {

    @Test
    void addProductSucessfully(){
        System.out.println("my first unit test");
    }
}
