package com.codesnippet.springdemoapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringdemoapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
