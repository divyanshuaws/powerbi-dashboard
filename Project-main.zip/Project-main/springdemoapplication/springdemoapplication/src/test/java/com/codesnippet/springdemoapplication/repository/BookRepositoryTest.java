package com.codesnippet.springdemoapplication.repository;

import static org.junit.jupiter.api.Assertions.*;

class BookRepositoryTest {

}